package com.example.gymflow

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ExerciseSetDao {

    @Insert
    suspend fun insertSets(sets: List<ExerciseSetEntity>)

    @Delete
    suspend fun deleteSet(set: ExerciseSetEntity)

    @Query(
        """
        SELECT *
        FROM exercise_sets
        WHERE sessionId = :sessionId
        ORDER BY exerciseName ASC, setNumber ASC
        """
    )
    suspend fun getSetsForSession(sessionId: Long): List<ExerciseSetEntity>

    @Query(
        """
        SELECT *
        FROM exercise_sets
        ORDER BY id DESC
        """
    )
    suspend fun getAllSets(): List<ExerciseSetEntity>
}

