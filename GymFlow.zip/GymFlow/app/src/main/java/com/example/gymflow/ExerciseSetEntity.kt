package com.example.gymflow


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exercise_sets")
data class ExerciseSetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val sessionId: Long,

    val exerciseName: String,
    val setNumber: Int,

    val weight: Float,
    val reps: Int,

    val completed: Boolean
)