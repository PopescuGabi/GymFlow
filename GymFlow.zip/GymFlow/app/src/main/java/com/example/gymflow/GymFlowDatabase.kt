package com.example.gymflow

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase


@Database(
    entities = [
        WorkoutSessionEntity::class,
        ExerciseSetEntity::class,
        ScheduleEventEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class GymFlowDatabase : RoomDatabase() {

    abstract fun workoutSessionDao(): WorkoutSessionDao

    abstract fun exerciseSetDao(): ExerciseSetDao

    abstract fun scheduleEventDao(): ScheduleEventDao

    companion object {

        @Volatile
        private var INSTANCE: GymFlowDatabase? = null

        private val MIGRATION_1_2 =
            object : Migration(1, 2) {

                override fun migrate(
                    database: SupportSQLiteDatabase
                ) {

                    database.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS schedule_events (
                            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            eventDate TEXT NOT NULL,
                            title TEXT NOT NULL,
                            startMinutes INTEGER NOT NULL,
                            endMinutes INTEGER NOT NULL,
                            category TEXT NOT NULL,
                            notes TEXT NOT NULL
                        )
                        """.trimIndent()
                    )
                }
            }

        fun getInstance(
            context: Context
        ): GymFlowDatabase {

            return INSTANCE
                ?: synchronized(this) {

                    INSTANCE
                        ?: Room.databaseBuilder(
                            context.applicationContext,
                            GymFlowDatabase::class.java,
                            "gymflow_database"
                        )
                            .addMigrations(
                                MIGRATION_1_2
                            )
                            .build()
                            .also { database ->
                                INSTANCE = database
                            }
                }
        }
    }
}