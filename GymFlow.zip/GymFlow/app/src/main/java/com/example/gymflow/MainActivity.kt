
package com.example.gymflow
import android.app.Activity
import androidx.lifecycle.lifecycleScope

import android.os.Bundle
import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.credentials.CredentialManager
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.sin
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.ColorUtils
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import kotlinx.coroutines.launch


class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        GymFlowNotifications.createChannel(this)

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                1001
            )
        }

        setContent {
            GymFlowApp()
        }
    }
}


/* ============================================================
   DATA
   ============================================================ */

enum class WorkoutType {
    TRAINING,
    REST
}

data class Exercise(
    val name: String,
    val sets: Int = 3,
    val reps: String = "8-12"
)

data class WorkoutDay(
    val day: DayOfWeek,
    val name: String,
    val estimatedMinutes: Int,
    val type: WorkoutType,
    val color: Color,
    val exercises: List<Exercise> = emptyList()
)

data class WorkoutSplit(
    val id: Int,
    val name: String,
    val days: Map<DayOfWeek, WorkoutDay>
)


data class WorkoutSetInput(
    val weight: String = "",
    val reps: String = "",
    val completed: Boolean = false
)

data class ExerciseProgressPoint(
    val dateLabel: String,
    val value: Float
)

data class AvailableSlot(
    val startMinutes: Int,
    val endMinutes: Int
)


/* ============================================================
   COLOR SYSTEM
   ============================================================ */

fun getCardColor(baseColor: Color): Color {

    val hsl = FloatArray(3)

    ColorUtils.colorToHSL(
        baseColor.toArgb(),
        hsl
    )

    hsl[2] = (hsl[2] + 0.10f)
        .coerceAtMost(0.95f)

    return Color(
        ColorUtils.HSLToColor(hsl)
    ).copy(alpha = 0.40f)
}


fun getTextColor(baseColor: Color): Color {

    val hsl = FloatArray(3)

    ColorUtils.colorToHSL(
        baseColor.toArgb(),
        hsl
    )

    hsl[1] = hsl[1] * 0.45f

    hsl[2] = (hsl[2] + 0.55f)
        .coerceAtMost(0.98f)

    return Color(
        ColorUtils.HSLToColor(hsl)
    )
}


fun getSecondaryTextColor(baseColor: Color): Color {

    val hsl = FloatArray(3)

    ColorUtils.colorToHSL(
        baseColor.toArgb(),
        hsl
    )

    hsl[1] = hsl[1] * 0.35f

    hsl[2] = (hsl[2] + 0.40f)
        .coerceAtMost(0.90f)

    return Color(
        ColorUtils.HSLToColor(hsl)
    )
}


/* ============================================================
   DEFAULT SPLIT
   ============================================================ */

fun createDefaultSplit(
    id: Int,
    splitName: String = "My First Split"
): WorkoutSplit {

    val defaultColor = Color(0xFF303030)

    return WorkoutSplit(
        id = id,
        name = splitName,
        days = mapOf(

            DayOfWeek.MONDAY to WorkoutDay(
                day = DayOfWeek.MONDAY,
                name = "Chest",
                estimatedMinutes = 75,
                type = WorkoutType.TRAINING,
                color = defaultColor,
                exercises = listOf(
                    Exercise("Bench Press"),
                    Exercise("Incline Dumbbell Press"),
                    Exercise("Cable Fly")
                )
            ),

            DayOfWeek.TUESDAY to WorkoutDay(
                day = DayOfWeek.TUESDAY,
                name = "Back",
                estimatedMinutes = 75,
                type = WorkoutType.TRAINING,
                color = defaultColor,
                exercises = listOf(
                    Exercise("Pull Ups"),
                    Exercise("Barbell Row"),
                    Exercise("Lat Pulldown")
                )
            ),

            DayOfWeek.WEDNESDAY to WorkoutDay(
                day = DayOfWeek.WEDNESDAY,
                name = "Rest",
                estimatedMinutes = 0,
                type = WorkoutType.REST,
                color = defaultColor
            ),

            DayOfWeek.THURSDAY to WorkoutDay(
                day = DayOfWeek.THURSDAY,
                name = "Legs",
                estimatedMinutes = 90,
                type = WorkoutType.TRAINING,
                color = defaultColor,
                exercises = listOf(
                    Exercise("Squat"),
                    Exercise("Leg Press"),
                    Exercise("Leg Curl")
                )
            ),

            DayOfWeek.FRIDAY to WorkoutDay(
                day = DayOfWeek.FRIDAY,
                name = "Arms",
                estimatedMinutes = 60,
                type = WorkoutType.TRAINING,
                color = defaultColor,
                exercises = listOf(
                    Exercise("Barbell Curl"),
                    Exercise("Tricep Pushdown"),
                    Exercise("Hammer Curl")
                )
            ),

            DayOfWeek.SATURDAY to WorkoutDay(
                day = DayOfWeek.SATURDAY,
                name = "Rest",
                estimatedMinutes = 0,
                type = WorkoutType.REST,
                color = defaultColor
            ),

            DayOfWeek.SUNDAY to WorkoutDay(
                day = DayOfWeek.SUNDAY,
                name = "Rest",
                estimatedMinutes = 0,
                type = WorkoutType.REST,
                color = defaultColor
            )
        )
    )
}


/* ============================================================
   TODAY
   ============================================================ */

fun getWorkoutForToday(
    split: WorkoutSplit
): WorkoutDay {

    val today = LocalDate.now().dayOfWeek

    return split.days[today]
        ?: WorkoutDay(
            day = today,
            name = "Rest",
            estimatedMinutes = 0,
            type = WorkoutType.REST,
            color = Color(0xFF303030)
        )
}


fun getWorkoutThemeColor(workout: WorkoutDay): Color {
    return if (workout.type == WorkoutType.TRAINING) {
        workout.color
    } else {
        Color(0xFF303030)
    }
}


private fun Modifier.glassCard(
    cardColor: Color,
    cornerRadius: androidx.compose.ui.unit.Dp
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .background(
            color = cardColor.copy(alpha = 0.36f),
            shape = shape
        )
        .border(
            width = 1.dp,
            color = Color.White.copy(alpha = 0.11f),
            shape = shape
        )
}

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    cardColor: Color,
    cornerRadius: androidx.compose.ui.unit.Dp,
    glowColor: Color = Color.White.copy(alpha = 0.16f),
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .blur(24.dp)
                .background(
                    color = glowColor,
                    shape = shape
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    color = cardColor.copy(alpha = 0.38f),
                    shape = shape
                )
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.12f),
                    shape = shape
                )
        ) {
            content()
        }
    }
}

@Composable
fun LiquidGlassBackdrop(baseColor: Color) {
    Box(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .size(260.dp)
                .align(Alignment.TopEnd)
                .offset(x = 60.dp, y = 80.dp)
                .blur(80.dp)
                .background(
                    color = getTextColor(baseColor).copy(alpha = 0.14f),
                    shape = CircleShape
                )
        )
        Box(
            modifier = Modifier
                .size(220.dp)
                .align(Alignment.BottomStart)
                .offset(x = (-50).dp, y = (-80).dp)
                .blur(72.dp)
                .background(
                    color = getTextColor(baseColor).copy(alpha = 0.10f),
                    shape = CircleShape
                )
        )
    }
}

@Composable
fun NavIcon(
    name: String,
    color: Color,
    selected: Boolean
) {
    Box(
        modifier = Modifier.size(30.dp),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .blur(12.dp)
                    .background(
                        color = color.copy(alpha = 0.28f),
                        shape = CircleShape
                    )
            )
        }
        Canvas(modifier = Modifier.size(21.dp)) {
            val stroke = if (selected) 2.1f else 1.65f
            when (name) {
                "HOME" -> {
                    val path = Path().apply {
                        moveTo(size.width * .13f, size.height * .47f)
                        lineTo(size.width * .50f, size.height * .14f)
                        lineTo(size.width * .87f, size.height * .47f)
                        lineTo(size.width * .79f, size.height * .47f)
                        lineTo(size.width * .79f, size.height * .84f)
                        lineTo(size.width * .21f, size.height * .84f)
                        lineTo(size.width * .21f, size.height * .47f)
                        close()
                    }
                    drawPath(path, color, style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke))
                    drawLine(color, Offset(size.width * .44f, size.height * .84f), Offset(size.width * .44f, size.height * .59f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .44f, size.height * .59f), Offset(size.width * .59f, size.height * .59f), strokeWidth = stroke)
                }
                "CALENDAR" -> {
                    drawRoundRect(
                        color = color,
                        topLeft = Offset(2f, 4f),
                        size = androidx.compose.ui.geometry.Size(size.width - 4f, size.height - 6f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                    )
                    drawLine(color, Offset(2f, size.height * .34f), Offset(size.width - 2f, size.height * .34f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .34f, 2f), Offset(size.width * .34f, 6f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .66f, 2f), Offset(size.width * .66f, 6f), strokeWidth = stroke)
                    drawCircle(color, 1.2f, Offset(size.width * .30f, size.height * .58f))
                    drawCircle(color, 1.2f, Offset(size.width * .50f, size.height * .58f))
                    drawCircle(color, 1.2f, Offset(size.width * .70f, size.height * .58f))
                }
                "SPLIT" -> {
                    val left = Offset(size.width * .25f, size.height * .50f)
                    val top = Offset(size.width * .75f, size.height * .27f)
                    val bottom = Offset(size.width * .75f, size.height * .73f)
                    drawCircle(color, 2f, left)
                    drawCircle(color, 2f, top)
                    drawCircle(color, 2f, bottom)
                    drawLine(color, Offset(size.width * .31f, size.height * .50f), Offset(size.width * .69f, size.height * .30f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .31f, size.height * .50f), Offset(size.width * .69f, size.height * .70f), strokeWidth = stroke)
                }
                "PROGRESS" -> {
                    drawLine(color, Offset(size.width * .17f, size.height * .82f), Offset(size.width * .17f, size.height * .18f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .17f, size.height * .82f), Offset(size.width * .85f, size.height * .82f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .23f, size.height * .68f), Offset(size.width * .39f, size.height * .55f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .39f, size.height * .55f), Offset(size.width * .58f, size.height * .62f), strokeWidth = stroke)
                    drawLine(color, Offset(size.width * .58f, size.height * .62f), Offset(size.width * .79f, size.height * .30f), strokeWidth = stroke)
                }
                "PROFILE" -> {
                    drawCircle(color, size.width * .17f, Offset(size.width * .50f, size.height * .30f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke))
                    val body = Path().apply {
                        moveTo(size.width * .23f, size.height * .82f)
                        cubicTo(size.width * .28f, size.height * .56f, size.width * .72f, size.height * .56f, size.width * .77f, size.height * .82f)
                    }
                    drawPath(body, color, style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke))
                }
            }
        }
    }
}



/* ============================================================
   GOOGLE AUTHENTICATION
   ============================================================ */

@Composable
fun GymFlowLoginScreen(
    isLoading: Boolean,
    errorMessage: String?,
    onContinueWithGoogle: () -> Unit
) {
    val background = Color(0xFF101010)
    val card = Color(0xFF1B1B1B)
    val primary = Color.White
    val secondary = Color(0xFF9B9B9B)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(background)
            .padding(horizontal = 28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "GYMFLOW",
                color = primary,
                fontSize = 42.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-1.5).sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "YOUR TRAINING. YOUR SCHEDULE.",
                color = secondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(48.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = card,
                        shape = RoundedCornerShape(28.dp)
                    )
                    .padding(24.dp)
            ) {
                Column {
                    Text(
                        text = "WELCOME",
                        color = primary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Sign in with your Google account to start using GymFlow.",
                        color = secondary,
                        fontSize = 15.sp,
                        lineHeight = 21.sp
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .clip(RoundedCornerShape(17.dp))
                            .clickable(enabled = !isLoading) {
                                onContinueWithGoogle()
                            }
                            .background(
                                color = primary,
                                shape = RoundedCornerShape(17.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isLoading) {
                                "SIGNING IN..."
                            } else {
                                "CONTINUE WITH GOOGLE"
                            },
                            color = Color.Black,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (!errorMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = errorMessage,
                            color = Color(0xFFE5A5A5),
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}


/* ============================================================
   MAIN APP
   ============================================================ */

@Composable
fun GymFlowApp() {
    val context = LocalContext.current
    val activity = context as? Activity
    val auth = remember { FirebaseAuth.getInstance() }

    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var authBusy by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            currentUser = firebaseAuth.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    if (currentUser == null) {
        GymFlowLoginScreen(
            isLoading = authBusy,
            errorMessage = authError,
            onContinueWithGoogle = {
                if (activity == null) return@GymFlowLoginScreen

                authBusy = true
                authError = null

                val credentialManager = CredentialManager.create(context)

                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(
                        context.getString(R.string.default_web_client_id)
                    )
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                activity.lifecycleScope.launch {
                    try {
                        val result = credentialManager.getCredential(
                            context = activity,
                            request = request
                        )

                        val credential = result.credential
                        val googleCredential =
                            GoogleIdTokenCredential.createFrom(credential.data)

                        val firebaseCredential =
                            GoogleAuthProvider.getCredential(
                                googleCredential.idToken,
                                null
                            )

                        auth.signInWithCredential(firebaseCredential)
                            .addOnCompleteListener { task ->
                                authBusy = false

                                if (!task.isSuccessful) {
                                    authError =
                                        task.exception?.localizedMessage
                                            ?: "Google sign-in failed."
                                }
                            }
                    } catch (e: GetCredentialException) {
                        authBusy = false
                        authError =
                            e.localizedMessage ?: "Google sign-in was cancelled."
                    } catch (e: GoogleIdTokenParsingException) {
                        authBusy = false
                        authError = "Google sign-in returned an invalid account."
                    } catch (e: Exception) {
                        authBusy = false
                        authError =
                            e.localizedMessage ?: "Unable to sign in with Google."
                    }
                }
            }
        )
        return
    }

    var splits by remember {
        mutableStateOf(
            listOf(createDefaultSplit(1))
        )
    }

    var activeSplitId by remember { mutableStateOf(1) }
    var selectedScreen by remember { mutableStateOf("HOME") }
    var splitView by remember { mutableStateOf("LIBRARY") }
    var editingSplitId by remember { mutableStateOf(1) }

    val activeSplit =
        splits.firstOrNull { it.id == activeSplitId }
            ?: splits.first()

    val todayWorkout = getWorkoutForToday(activeSplit)
    val backgroundColor = todayWorkout.color
    val cardColor = getCardColor(backgroundColor)
    val textColor = getTextColor(backgroundColor)
    val secondaryTextColor = getSecondaryTextColor(backgroundColor)

    fun logout() {
        GymFlowNotifications.cancelDailyReminder(context)

        activity?.lifecycleScope?.launch {
            try {
                CredentialManager.create(context)
                    .clearCredentialState(ClearCredentialStateRequest())
            } catch (_: Exception) {
                // Firebase logout still proceeds if credential-state clearing
                // is unavailable on the current device.
            }
        }

        auth.signOut()
        selectedScreen = "HOME"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
    ) {
        val bottomPadding =
            if (selectedScreen == "WORKOUT") 0.dp else 96.dp

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = bottomPadding)
        ) {
            when (selectedScreen) {
                "HOME" -> HomeScreen(
                    split = activeSplit,
                    onStartWorkout = { selectedScreen = "WORKOUT" }
                )

                "WORKOUT" -> WorkoutScreen(
                    split = activeSplit,
                    onBack = { selectedScreen = "HOME" }
                )

                "CALENDAR" -> CalendarScreen(
                    split = activeSplit
                )

                "SPLIT" -> {
                    if (splitView == "LIBRARY") {
                        SplitLibraryScreen(
                            splits = splits,
                            activeSplitId = activeSplitId,
                            onUseSplit = { activeSplitId = it },
                            onEditSplit = {
                                editingSplitId = it
                                splitView = "EDITOR"
                            },
                            onAddSplit = {
                                val newId =
                                    (splits.maxOfOrNull { it.id } ?: 0) + 1

                                val newSplit = createDefaultSplit(
                                    id = newId,
                                    splitName = "New Split $newId"
                                )

                                splits = splits + newSplit
                                activeSplitId = newId
                                editingSplitId = newId
                                splitView = "EDITOR"
                            }
                        )
                    } else {
                        val selectedSplit =
                            splits.firstOrNull { it.id == editingSplitId }

                        if (selectedSplit != null) {
                            SplitEditorScreen(
                                split = selectedSplit,
                                isActive =
                                    selectedSplit.id == activeSplitId,
                                onBack = {
                                    splitView = "LIBRARY"
                                },
                                onUseSplit = {
                                    activeSplitId = selectedSplit.id
                                },
                                onSplitChanged = { updatedSplit ->
                                    splits = splits.map {
                                        if (it.id == updatedSplit.id) {
                                            updatedSplit
                                        } else {
                                            it
                                        }
                                    }
                                }
                            )
                        }
                    }
                }

                "PROGRESS" -> ProgressScreen(
                    split = activeSplit
                )

                "PROFILE" -> ProfileScreen(
                    splitCount = splits.size,
                    backgroundColor = backgroundColor,
                    cardColor = cardColor,
                    textColor = textColor,
                    secondaryTextColor = secondaryTextColor,
                    onLogout = ::logout
                )
            }
        }

        if (selectedScreen != "WORKOUT") {
            GymFlowBottomBar(
                selectedScreen = selectedScreen,
                onScreenSelected = { screen ->
                    selectedScreen = screen
                    if (screen == "SPLIT") {
                        splitView = "LIBRARY"
                    }
                },
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
fun HomeScreen(
    split: WorkoutSplit,
    onStartWorkout: () -> Unit
) {
    val todayWorkout = getWorkoutForToday(split)
    val backgroundColor = getWorkoutThemeColor(todayWorkout)
    val cardColor = getCardColor(backgroundColor)
    val textColor = getTextColor(backgroundColor)
    val secondaryTextColor = getSecondaryTextColor(backgroundColor)

    val title = if (todayWorkout.type == WorkoutType.REST) {
        "REST DAY"
    } else {
        "${todayWorkout.name.uppercase()} DAY"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 36.dp)
    ) {
        Text(
            text = "TODAY IS",
            color = textColor,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium
        )

        Text(
            text = title,
            color = textColor,
            fontSize = 56.sp,
            lineHeight = 58.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(top = 4.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(350.dp),
            contentAlignment = Alignment.Center
        ) {
            GreekStatueCharacter(
                workout = todayWorkout,
                accentColor = if (todayWorkout.type == WorkoutType.TRAINING) {
                    todayWorkout.color
                } else {
                    Color(0xFF777777)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(330.dp)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = cardColor,
                    shape = RoundedCornerShape(26.dp)
                )
                .padding(22.dp)
        ) {
            Column {
                Text(
                    text = "TODAY",
                    color = secondaryTextColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = if (todayWorkout.type == WorkoutType.REST) {
                        "Recovery day"
                    } else {
                        todayWorkout.name
                    },
                    color = textColor,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                if (todayWorkout.type == WorkoutType.TRAINING) {
                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "${todayWorkout.estimatedMinutes} min estimated",
                        color = secondaryTextColor,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .background(
                                color = textColor,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { onStartWorkout() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "START WORKOUT",
                            color = backgroundColor,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        MinimalInfoRow(
            title = "GYM REMINDER",
            value = "Not set",
            cardColor = cardColor,
            textColor = textColor,
            secondaryTextColor = secondaryTextColor
        )

        Spacer(modifier = Modifier.height(10.dp))

        MinimalInfoRow(
            title = "TODAY'S SCHEDULE",
            value = "No events yet",
            cardColor = cardColor,
            textColor = textColor,
            secondaryTextColor = secondaryTextColor
        )
    }
}

@Composable
private fun GreekStatueCharacter(
    workout: WorkoutDay,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "statue_idle")

    val breath by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "statue_breath"
    )

    val pose by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (workout.name.lowercase()) {
                    "legs" -> 1250
                    "arms" -> 1450
                    "chest" -> 1750
                    "back" -> 1850
                    else -> 2800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "statue_pose"
    )

    val sway by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "statue_sway"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val groundY = h * 0.94f
        val movement = sin(pose * PI).toFloat()
        val torsoScale = 1f + breath * 0.025f
        val statue = Color(0xFFE0DED8)
        val statueShadow = Color(0xFFB9B6AF)
        val deep = Color(0xFF242424)

        // Ground shadow
        drawOval(
            color = Color.Black.copy(alpha = 0.20f),
            topLeft = Offset(cx - w * 0.23f, groundY - h * 0.025f),
            size = Size(w * 0.46f, h * 0.045f)
        )

        rotate(
            degrees = sway * 1.1f,
            pivot = Offset(cx, groundY)
        ) {
            // Legs: strong, simplified marble silhouette.
            val legSpread = w * 0.035f + movement * w * 0.012f
            val leftLegX = cx - w * 0.075f - legSpread
            val rightLegX = cx + w * 0.075f + legSpread

            drawRoundRect(
                color = statueShadow,
                topLeft = Offset(leftLegX - w * 0.045f, h * 0.62f),
                size = Size(w * 0.09f, h * 0.27f),
                cornerRadius = CornerRadius(w * 0.045f, w * 0.045f)
            )
            drawRoundRect(
                color = statue,
                topLeft = Offset(rightLegX - w * 0.045f, h * 0.62f),
                size = Size(w * 0.09f, h * 0.27f),
                cornerRadius = CornerRadius(w * 0.045f, w * 0.045f)
            )

            // Feet.
            drawOval(
                color = deep,
                topLeft = Offset(leftLegX - w * 0.085f, h * 0.87f),
                size = Size(w * 0.16f, h * 0.055f)
            )
            drawOval(
                color = deep,
                topLeft = Offset(rightLegX - w * 0.075f, h * 0.87f),
                size = Size(w * 0.16f, h * 0.055f)
            )

            // Arms / pose.
            when (workout.name.lowercase()) {
                "chest" -> {
                    // Open, proud chest pose.
                    rotate(-8f - movement * 7f, Offset(cx - w * 0.19f, h * 0.42f)) {
                        drawRoundRect(
                            color = statueShadow,
                            topLeft = Offset(cx - w * 0.25f, h * 0.39f),
                            size = Size(w * 0.07f, h * 0.27f),
                            cornerRadius = CornerRadius(w * 0.035f, w * 0.035f)
                        )
                    }
                    rotate(8f + movement * 7f, Offset(cx + w * 0.19f, h * 0.42f)) {
                        drawRoundRect(
                            color = statue,
                            topLeft = Offset(cx + w * 0.18f, h * 0.39f),
                            size = Size(w * 0.07f, h * 0.27f),
                            cornerRadius = CornerRadius(w * 0.035f, w * 0.035f)
                        )
                    }
                }
                "back" -> {
                    // Arms pulled slightly behind to emphasize the back silhouette.
                    rotate(24f + movement * 8f, Offset(cx - w * 0.17f, h * 0.42f)) {
                        drawRoundRect(
                            color = statueShadow,
                            topLeft = Offset(cx - w * 0.22f, h * 0.36f),
                            size = Size(w * 0.075f, h * 0.28f),
                            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
                        )
                    }
                    rotate(-24f - movement * 8f, Offset(cx + w * 0.17f, h * 0.42f)) {
                        drawRoundRect(
                            color = statue,
                            topLeft = Offset(cx + w * 0.145f, h * 0.36f),
                            size = Size(w * 0.075f, h * 0.28f),
                            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
                        )
                    }
                }
                "legs" -> {
                    // Hands resting near hips, slight squat pulse.
                    val dip = movement * h * 0.025f
                    drawRoundRect(
                        color = statueShadow,
                        topLeft = Offset(cx - w * 0.24f, h * 0.45f + dip),
                        size = Size(w * 0.07f, h * 0.19f),
                        cornerRadius = CornerRadius(w * 0.035f, w * 0.035f)
                    )
                    drawRoundRect(
                        color = statue,
                        topLeft = Offset(cx + w * 0.17f, h * 0.45f + dip),
                        size = Size(w * 0.07f, h * 0.19f),
                        cornerRadius = CornerRadius(w * 0.035f, w * 0.035f)
                    )
                }
                "arms" -> {
                    // Classic biceps pose, but kept as an abstract silhouette.
                    val lift = movement * 10f
                    rotate(-38f - lift, Offset(cx - w * 0.17f, h * 0.40f)) {
                        drawRoundRect(
                            color = statueShadow,
                            topLeft = Offset(cx - w * 0.23f, h * 0.25f),
                            size = Size(w * 0.075f, h * 0.25f),
                            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
                        )
                    }
                    rotate(38f + lift, Offset(cx + w * 0.17f, h * 0.40f)) {
                        drawRoundRect(
                            color = statue,
                            topLeft = Offset(cx + w * 0.155f, h * 0.25f),
                            size = Size(w * 0.075f, h * 0.25f),
                            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
                        )
                    }
                }
                else -> {
                    // Rest: relaxed neutral pose.
                    drawRoundRect(
                        color = statueShadow,
                        topLeft = Offset(cx - w * 0.22f, h * 0.40f),
                        size = Size(w * 0.07f, h * 0.28f),
                        cornerRadius = CornerRadius(w * 0.035f, w * 0.035f)
                    )
                    drawRoundRect(
                        color = statue,
                        topLeft = Offset(cx + w * 0.15f, h * 0.40f),
                        size = Size(w * 0.07f, h * 0.28f),
                        cornerRadius = CornerRadius(w * 0.035f, w * 0.035f)
                    )
                }
            }

            // Torso: wide shoulders, narrow waist, marble-like highlight.
            val torsoTop = h * 0.31f
            drawRoundRect(
                color = statueShadow,
                topLeft = Offset(cx - w * 0.18f, torsoTop),
                size = Size(w * 0.36f * torsoScale, h * 0.34f * torsoScale),
                cornerRadius = CornerRadius(w * 0.10f, w * 0.10f)
            )
            drawRoundRect(
                color = statue,
                topLeft = Offset(cx - w * 0.145f, torsoTop + h * 0.01f),
                size = Size(w * 0.29f * torsoScale, h * 0.30f * torsoScale),
                cornerRadius = CornerRadius(w * 0.085f, w * 0.085f)
            )

            // Accent band makes the statue belong to the current workout theme.
            drawRoundRect(
                color = accentColor.copy(alpha = 0.80f),
                topLeft = Offset(cx - w * 0.105f, h * 0.47f),
                size = Size(w * 0.21f, h * 0.035f),
                cornerRadius = CornerRadius(w * 0.018f, w * 0.018f)
            )

            // Neck.
            drawRoundRect(
                color = statue,
                topLeft = Offset(cx - w * 0.055f, h * 0.24f),
                size = Size(w * 0.11f, h * 0.10f),
                cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
            )

            // Head.
            val headY = h * 0.17f - breath * h * 0.006f
            drawCircle(
                color = statue,
                radius = w * 0.105f,
                center = Offset(cx, headY)
            )

            // Stylized Greek-inspired hair/crown silhouette.
            drawArc(
                color = deep,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = Offset(cx - w * 0.105f, headY - w * 0.105f),
                size = Size(w * 0.21f, w * 0.15f)
            )

            // Minimal face — no detailed realism.
            drawCircle(
                color = deep,
                radius = w * 0.008f,
                center = Offset(cx - w * 0.035f, headY + w * 0.012f)
            )
            drawCircle(
                color = deep,
                radius = w * 0.008f,
                center = Offset(cx + w * 0.035f, headY + w * 0.012f)
            )

            // Marble cracks / contour marks.
            drawLine(
                color = accentColor.copy(alpha = 0.45f),
                start = Offset(cx - w * 0.075f, h * 0.55f),
                end = Offset(cx - w * 0.025f, h * 0.61f),
                strokeWidth = w * 0.008f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = accentColor.copy(alpha = 0.35f),
                start = Offset(cx + w * 0.07f, h * 0.53f),
                end = Offset(cx + w * 0.035f, h * 0.59f),
                strokeWidth = w * 0.006f,
                cap = StrokeCap.Round
            )
        }
    }
}


/* ============================================================
   WORKOUT SCREEN
   ============================================================ */

@Composable
fun WorkoutScreen(
    split: WorkoutSplit,
    onBack: () -> Unit,
    onFinishWorkout: (WorkoutDay, Long, List<WorkoutSetInput>) -> Unit
) {
    val workout = getWorkoutForToday(split)
    val backgroundColor = getWorkoutThemeColor(workout)
    val cardColor = getCardColor(backgroundColor)
    val textColor = getTextColor(backgroundColor)
    val secondaryTextColor = getSecondaryTextColor(backgroundColor)
    val startedAt = remember { System.currentTimeMillis() }
    val setInputs = remember { mutableStateMapOf<String, WorkoutSetInput>() }

    if (workout.type == WorkoutType.REST) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundColor)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "‹",
                color = textColor,
                fontSize = 34.sp,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "REST DAY",
                color = textColor,
                fontSize = 44.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-1).sp
            )
            Text(
                text = "NO WORKOUT SCHEDULED",
                color = secondaryTextColor,
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 26.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "‹",
                color = textColor,
                fontSize = 34.sp,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "WORKOUT",
                color = secondaryTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
        }

        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = workout.name.uppercase(),
            color = textColor,
            fontSize = 46.sp,
            lineHeight = 46.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-1).sp
        )
        Text(
            text = "${workout.exercises.size} EXERCISES · ${workout.estimatedMinutes} MIN",
            color = secondaryTextColor,
            fontSize = 11.sp,
            letterSpacing = 0.8.sp,
            modifier = Modifier.padding(top = 5.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))
        Hairline(textColor.copy(alpha = 0.18f))
        Spacer(modifier = Modifier.height(8.dp))

        workout.exercises.forEachIndexed { index, exercise ->
            WorkoutExerciseCard(
                exercise = exercise,
                index = index + 1,
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                setInputs = setInputs
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    textColor.copy(alpha = 0.42f),
                    RoundedCornerShape(16.dp)
                )
                .clickable {
                    onFinishWorkout(
                        workout,
                        startedAt,
                        workout.exercises.flatMap { exercise ->
                            (1..exercise.sets).map { setIndex ->
                                setInputs["${exercise.name}-$setIndex"] ?: WorkoutSetInput()
                            }
                        }
                    )
                }
                .padding(vertical = 18.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "FINISH WORKOUT",
                color = textColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun WorkoutExerciseCard(
    exercise: Exercise,
    index: Int,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    setInputs: MutableMap<String, WorkoutSetInput>
) {
    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        cardColor = cardColor,
        cornerRadius = 22.dp,
        glowColor = textColor.copy(alpha = 0.09f)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "%02d".format(index),
                    color = secondaryTextColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = exercise.name,
                        color = textColor,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${exercise.sets} SETS · ${exercise.reps} TARGET",
                        color = secondaryTextColor,
                        fontSize = 10.sp,
                        letterSpacing = 0.7.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            repeat(exercise.sets) { setIndex ->
                WorkoutSetRow(
                    setNumber = setIndex + 1,
                    textColor = textColor,
                    secondaryTextColor = secondaryTextColor,
                    stateKey = "${exercise.name}-${setIndex + 1}",
                    setInputs = setInputs
                )
                if (setIndex < exercise.sets - 1) {
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
fun WorkoutSetRow(
    setNumber: Int,
    textColor: Color,
    secondaryTextColor: Color,
    stateKey: String,
    setInputs: MutableMap<String, WorkoutSetInput>
) {
    val state = setInputs[stateKey] ?: WorkoutSetInput()

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "%02d".format(setNumber),
            color = secondaryTextColor,
            fontSize = 10.sp,
            modifier = Modifier.width(28.dp)
        )

        OutlinedTextField(
            value = state.weight,
            onValueChange = { value ->
                setInputs[stateKey] = state.copy(weight = value.filter { it.isDigit() || it == '.' })
            },
            label = { Text("KG") },
            singleLine = true,
            modifier = Modifier.weight(1f)
        )

        Spacer(modifier = Modifier.width(8.dp))

        OutlinedTextField(
            value = state.reps,
            onValueChange = { value ->
                setInputs[stateKey] = state.copy(reps = value.filter { it.isDigit() })
            },
            label = { Text("REPS") },
            singleLine = true,
            modifier = Modifier.weight(1f)
        )

        Spacer(modifier = Modifier.width(10.dp))

        Box(
            modifier = Modifier
                .size(22.dp)
                .border(
                    1.dp,
                    textColor.copy(alpha = 0.55f),
                    CircleShape
                )
                .background(
                    if (state.completed) textColor else Color.Transparent,
                    CircleShape
                )
                .clickable {
                    setInputs[stateKey] = state.copy(completed = !state.completed)
                },
            contentAlignment = Alignment.Center
        ) {
            if (state.completed) {
                Text(
                    text = "✓",
                    color = Color.Black,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun MinimalInfoRow(
    title: String,
    value: String,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color
) {
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        cardColor = cardColor,
        cornerRadius = 18.dp,
        glowColor = textColor.copy(alpha = 0.07f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = secondaryTextColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = value,
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Text(text = "›", color = secondaryTextColor, fontSize = 22.sp)
        }
    }
}

@Composable
fun CalendarScreen(
    split: WorkoutSplit,
    selectedDate: LocalDate,
    onSelectedDateChange: (LocalDate) -> Unit
) {
    val today = LocalDate.now()
    val context = LocalContext.current
    val database = remember { GymFlowDatabase.getInstance(context) }
    val coroutineScope = rememberCoroutineScope()

    var visibleMonth by remember { mutableStateOf(YearMonth.from(selectedDate)) }
    var monthEvents by remember { mutableStateOf<List<ScheduleEventEntity>>(emptyList()) }
    var showAddSchedule by remember { mutableStateOf(false) }

    LaunchedEffect(visibleMonth) {
        monthEvents = database.scheduleEventDao().getEventsForDateRange(
            visibleMonth.atDay(1).toString(),
            visibleMonth.atEndOfMonth().toString()
        )
    }

    val selectedWorkout = split.days[selectedDate.dayOfWeek] ?: WorkoutDay(
        day = selectedDate.dayOfWeek,
        name = "Rest",
        estimatedMinutes = 0,
        type = WorkoutType.REST,
        color = Color(0xFF303030)
    )

    val backgroundColor = getWorkoutThemeColor(selectedWorkout)
    val cardColor = getCardColor(backgroundColor)
    val textColor = getTextColor(backgroundColor)
    val secondaryTextColor = getSecondaryTextColor(backgroundColor)

    val scheduleEvents = monthEvents.filter { it.eventDate == selectedDate.toString() }
    val availableSlots = buildAvailableSlots(scheduleEvents)
    val firstDayOffset = visibleMonth.atDay(1).dayOfWeek.value - 1
    val daysInMonth = visibleMonth.lengthOfMonth()
    val totalCells = ((firstDayOffset + daysInMonth + 6) / 7) * 7

    LaunchedEffect(selectedDate) {
        if (YearMonth.from(selectedDate) != visibleMonth) {
            visibleMonth = YearMonth.from(selectedDate)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 26.dp)
    ) {
        Text(
            text = "CALENDAR",
            color = textColor,
            fontSize = 40.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-1).sp
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "‹",
                color = textColor,
                fontSize = 30.sp,
                modifier = Modifier.clickable {
                    val newMonth = visibleMonth.minusMonths(1)
                    visibleMonth = newMonth
                    val day = selectedDate.dayOfMonth.coerceAtMost(newMonth.lengthOfMonth())
                    onSelectedDateChange(newMonth.atDay(day))
                }
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = visibleMonth.month.name
                    .lowercase()
                    .replaceFirstChar { it.uppercase() } + " ${visibleMonth.year}",
                color = secondaryTextColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "TODAY",
                color = textColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable {
                    visibleMonth = YearMonth.from(today)
                    onSelectedDateChange(today)
                }
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "›",
                color = textColor,
                fontSize = 30.sp,
                modifier = Modifier.clickable {
                    val newMonth = visibleMonth.plusMonths(1)
                    visibleMonth = newMonth
                    val day = selectedDate.dayOfMonth.coerceAtMost(newMonth.lengthOfMonth())
                    onSelectedDateChange(newMonth.atDay(day))
                }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN").forEach {
                Text(
                    text = it,
                    color = secondaryTextColor,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(38.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        for (week in 0 until totalCells / 7) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                for (column in 0 until 7) {
                    val cellIndex = week * 7 + column
                    val dayNumber = cellIndex - firstDayOffset + 1
                    if (dayNumber in 1..daysInMonth) {
                        val date = visibleMonth.atDay(dayNumber)
                        val workout = split.days[date.dayOfWeek]
                        val selected = date == selectedDate
                        val isToday = date == today
                        val hasEvents = monthEvents.any { it.eventDate == date.toString() }

                        Box(
                            modifier = Modifier
                                .width(38.dp)
                                .height(54.dp)
                                .clickable { onSelectedDateChange(date) },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        color = if (selected) textColor.copy(alpha = 0.08f) else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .border(
                                        width = if (selected || (isToday && !selected)) 1.dp else 0.dp,
                                        color = if (selected) Color.White.copy(alpha = 0.20f) else secondaryTextColor.copy(alpha = 0.45f),
                                        shape = RoundedCornerShape(12.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dayNumber.toString(),
                                        color = textColor,
                                        fontSize = 14.sp,
                                        fontWeight = if (selected || isToday) FontWeight.Bold else FontWeight.Normal
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                        if (workout?.type == WorkoutType.TRAINING) {
                                            Box(
                                                modifier = Modifier
                                                    .size(5.dp)
                                                    .background(workout.color, CircleShape)
                                            )
                                        }
                                        if (hasEvents) {
                                            Box(
                                                modifier = Modifier
                                                    .size(5.dp)
                                                    .background(textColor.copy(alpha = 0.75f), CircleShape)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.width(38.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))
        Hairline(textColor.copy(alpha = 0.18f))
        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = selectedDate.dayOfWeek.name,
            color = secondaryTextColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Text(
            text = "${selectedDate.dayOfMonth} ${selectedDate.month.name.lowercase().replaceFirstChar { it.uppercase() }}",
            color = textColor,
            fontSize = 32.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = if (selectedWorkout.type == WorkoutType.REST) "RECOVERY" else selectedWorkout.name.uppercase(),
            color = textColor,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = if (selectedWorkout.type == WorkoutType.REST) "NO WORKOUT ASSIGNED" else "${selectedWorkout.estimatedMinutes} MIN · ${selectedWorkout.exercises.size} EXERCISES",
            color = secondaryTextColor,
            fontSize = 11.sp,
            letterSpacing = 0.7.sp,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "DAY PLAN",
                color = secondaryTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .clickable { showAddSchedule = true }
                    .background(textColor.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "+ ADD",
                    color = textColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        if (scheduleEvents.isEmpty()) {
            ScheduleEmptyCard(
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                onAdd = { showAddSchedule = true }
            )
        } else {
            scheduleEvents.forEach { event ->
                ScheduleEventRow(
                    event = event,
                    cardColor = cardColor,
                    textColor = textColor,
                    secondaryTextColor = secondaryTextColor,
                    onDelete = {
                        coroutineScope.launch {
                            database.scheduleEventDao().deleteEvent(event.id)
                            monthEvents = monthEvents.filterNot { it.id == event.id }
                        }
                    }
                )
                Spacer(modifier = Modifier.height(4.dp))
            }
        }

        if (selectedWorkout.type == WorkoutType.TRAINING && availableSlots.any { it.endMinutes - it.startMinutes >= selectedWorkout.estimatedMinutes }) {
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "WORKOUT FIT",
                color = secondaryTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            availableSlots.filter { it.endMinutes - it.startMinutes >= selectedWorkout.estimatedMinutes }.take(3).forEach { slot ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${formatMinutes(slot.startMinutes)} — ${formatMinutes(slot.endMinutes)}",
                        color = textColor,
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${selectedWorkout.estimatedMinutes} MIN",
                        color = secondaryTextColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showAddSchedule) {
        AddScheduleEventDialog(
            selectedDate = selectedDate,
            backgroundColor = backgroundColor,
            cardColor = cardColor,
            textColor = textColor,
            secondaryTextColor = secondaryTextColor,
            onDismiss = { showAddSchedule = false },
            onAdd = { event ->
                coroutineScope.launch {
                    val id = database.scheduleEventDao().insertEvent(event)
                    monthEvents = (monthEvents + event.copy(id = id)).sortedWith(
                        compareBy<ScheduleEventEntity> { it.eventDate }.thenBy { it.startMinutes }
                    )
                    showAddSchedule = false
                }
            }
        )
    }
}

fun formatMinutes(totalMinutes: Int): String {
    if (totalMinutes >= 24 * 60) return "24:00"
    val hours = (totalMinutes / 60).coerceIn(0, 23)
    val minutes = totalMinutes % 60
    return "%02d:%02d".format(hours, minutes)
}

fun parseTimeMinutes(value: String): Int? {
    val parts = value.trim().split(":")
    if (parts.size != 2) return null

    val hour = parts[0].toIntOrNull() ?: return null
    val minute = parts[1].toIntOrNull() ?: return null

    if (hour !in 0..23 || minute !in 0..59) return null

    return hour * 60 + minute
}

fun buildAvailableSlots(
    events: List<ScheduleEventEntity>,
    dayStart: Int = 6 * 60,
    dayEnd: Int = 24 * 60
): List<AvailableSlot> {
    val sorted = events
        .sortedBy { it.startMinutes }
        .map {
            it.startMinutes.coerceIn(dayStart, dayEnd) to
                    it.endMinutes.coerceIn(dayStart, dayEnd)
        }

    val slots = mutableListOf<AvailableSlot>()
    var cursor = dayStart

    sorted.forEach { (start, end) ->
        if (start > cursor) {
            slots += AvailableSlot(cursor, start)
        }
        cursor = maxOf(cursor, end)
    }

    if (cursor < dayEnd) {
        slots += AvailableSlot(cursor, dayEnd)
    }

    return slots
}

@Composable
fun ScheduleEmptyCard(
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onAdd: () -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onAdd() },
        cardColor = cardColor,
        cornerRadius = 20.dp,
        glowColor = textColor.copy(alpha = 0.06f)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "NO EVENTS YET",
                color = textColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "ADD CLASSES, STUDY, WORK, ERRANDS OR GYM TIME.",
                color = secondaryTextColor,
                fontSize = 10.sp,
                letterSpacing = 0.6.sp,
                modifier = Modifier.padding(top = 5.dp)
            )
            Text(
                text = "+ ADD TIME BLOCK",
                color = textColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
                modifier = Modifier.padding(top = 13.dp)
            )
        }
    }
}

@Composable
fun ScheduleEventRow(
    event: ScheduleEventEntity,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onDelete: () -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        cardColor = cardColor,
        cornerRadius = 18.dp,
        glowColor = textColor.copy(alpha = 0.07f)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.width(62.dp)) {
                Text(
                    text = formatMinutes(event.startMinutes),
                    color = textColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = formatMinutes(event.endMinutes),
                    color = secondaryTextColor,
                    fontSize = 9.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(42.dp)
                    .background(textColor.copy(alpha = 0.35f))
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = event.title,
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = event.category,
                    color = secondaryTextColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.7.sp,
                    modifier = Modifier.padding(top = 3.dp)
                )
                if (event.notes.isNotBlank()) {
                    Text(
                        text = event.notes,
                        color = secondaryTextColor,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            Text(
                text = "×",
                color = secondaryTextColor,
                fontSize = 18.sp,
                modifier = Modifier.clickable { onDelete() }
            )
        }
    }
}

@Composable
fun AddScheduleEventDialog(
    selectedDate: LocalDate,
    backgroundColor: Color,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onDismiss: () -> Unit,
    onAdd: (ScheduleEventEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var startTime by remember { mutableStateOf("09:00") }
    var endTime by remember { mutableStateOf("10:00") }
    var category by remember { mutableStateOf("PERSONAL") }
    var notes by remember { mutableStateOf("") }
    var categoryExpanded by remember { mutableStateOf(false) }

    val startMinutes = parseTimeMinutes(startTime)
    val endMinutes = parseTimeMinutes(endTime)
    val valid = title.isNotBlank() &&
            startMinutes != null &&
            endMinutes != null &&
            endMinutes > startMinutes

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .background(
                    color = Color(0xFF202020).copy(alpha = 0.94f),
                    shape = RoundedCornerShape(26.dp)
                )
                .border(
                    1.dp,
                    Color.White.copy(alpha = 0.13f),
                    RoundedCornerShape(26.dp)
                )
                .padding(22.dp)
        ) {
            Text(
                text = "ADD TIME BLOCK",
                color = textColor,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = selectedDate.toString(),
                color = secondaryTextColor,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("TITLE") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = startTime,
                    onValueChange = { startTime = it.filter { c -> c.isDigit() || c == ':' }.take(5) },
                    label = { Text("START · HH:MM") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(10.dp))

                OutlinedTextField(
                    value = endTime,
                    onValueChange = { endTime = it.filter { c -> c.isDigit() || c == ':' }.take(5) },
                    label = { Text("END · HH:MM") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = cardColor,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable { categoryExpanded = true }
                        .padding(16.dp)
                ) {
                    Column {
                        Text(
                            text = "CATEGORY",
                            color = secondaryTextColor,
                            fontSize = 10.sp
                        )
                        Text(
                            text = category,
                            color = textColor,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }

                DropdownMenu(
                    expanded = categoryExpanded,
                    onDismissRequest = { categoryExpanded = false }
                ) {
                    listOf(
                        "CLASS",
                        "WORK",
                        "STUDY",
                        "WORKOUT",
                        "PERSONAL",
                        "OTHER"
                    ).forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                category = option
                                categoryExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("NOTES · OPTIONAL") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (!valid) {
                Text(
                    text = "Use a title and a valid start/end time.",
                    color = secondaryTextColor,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            Row(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .background(
                            color = cardColor,
                            shape = RoundedCornerShape(13.dp)
                        )
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CANCEL",
                        color = textColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .background(
                            color = if (valid) textColor else textColor.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(13.dp)
                        )
                        .clickable(enabled = valid) {
                            onAdd(
                                ScheduleEventEntity(
                                    eventDate = selectedDate.toString(),
                                    title = title.trim(),
                                    startMinutes = startMinutes!!,
                                    endMinutes = endMinutes!!,
                                    category = category,
                                    notes = notes.trim()
                                )
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ADD",
                        color = backgroundColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}


/* ============================================================
   SPLIT LIBRARY
   ============================================================ */

@Composable
fun SplitLibraryScreen(
    splits: List<WorkoutSplit>,
    activeSplitId: Int,
    onUseSplit: (Int) -> Unit,
    onEditSplit: (Int) -> Unit,
    onAddSplit: () -> Unit
) {
    val activeSplit = splits.firstOrNull { it.id == activeSplitId } ?: splits.first()
    val backgroundColor = getWorkoutThemeColor(getWorkoutForToday(activeSplit))
    val cardColor = getCardColor(backgroundColor)
    val textColor = getTextColor(backgroundColor)
    val secondaryTextColor = getSecondaryTextColor(backgroundColor)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 28.dp)
    ) {
        Text(
            text = "SPLITS",
            color = textColor,
            fontSize = 40.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-1).sp
        )
        Text(
            text = "TRAINING PLANS",
            color = secondaryTextColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))
        splits.forEachIndexed { index, split ->
            SplitLibraryCard(
                split = split,
                isActive = split.id == activeSplitId,
                backgroundColor = backgroundColor,
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                onUse = { onUseSplit(split.id) },
                onEdit = { onEditSplit(split.id) }
            )
            if (index < splits.lastIndex) Spacer(modifier = Modifier.height(2.dp))
        }

        Spacer(modifier = Modifier.height(18.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(textColor.copy(alpha = 0.05f), RoundedCornerShape(14.dp))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(14.dp))
                .clickable { onAddSplit() }
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "+ ADD SPLIT",
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }
        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun SplitLibraryCard(
    split: WorkoutSplit,
    isActive: Boolean,
    backgroundColor: Color,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onUse: () -> Unit,
    onEdit: () -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() },
        cardColor = cardColor,
        cornerRadius = 22.dp,
        glowColor = textColor.copy(alpha = if (isActive) 0.12f else 0.06f)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .background(
                            if (isActive) textColor else secondaryTextColor.copy(alpha = 0.35f),
                            CircleShape
                        )
                )
                Spacer(modifier = Modifier.width(11.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = split.name,
                        color = textColor,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${split.days.count { it.value.type == WorkoutType.TRAINING }} TRAINING DAYS",
                        color = secondaryTextColor,
                        fontSize = 10.sp,
                        letterSpacing = 0.7.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
                Text(
                    text = if (isActive) "ACTIVE" else "USE",
                    color = if (isActive) secondaryTextColor else textColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = if (!isActive) Modifier.clickable { onUse() } else Modifier
                )
            }
        }
    }
}

@Composable
fun SplitEditorScreen(
    split: WorkoutSplit,
    isActive: Boolean,
    onBack: () -> Unit,
    onUseSplit: () -> Unit,
    onSplitChanged: (WorkoutSplit) -> Unit
) {
    var selectedTab by remember { mutableStateOf("SCHEDULE") }
    var selectedDay by remember { mutableStateOf(DayOfWeek.MONDAY) }
    var showDayEditor by remember { mutableStateOf(false) }
    var showAddExercise by remember { mutableStateOf(false) }
    var nameDraft by remember(split.id) { mutableStateOf(split.name) }

    val themeWorkout = getWorkoutForToday(split)
    val backgroundColor = getWorkoutThemeColor(themeWorkout)
    val cardColor = getCardColor(backgroundColor)
    val textColor = getTextColor(backgroundColor)
    val secondaryTextColor = getSecondaryTextColor(backgroundColor)
    val selectedWorkout = split.days[selectedDay]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 26.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "‹",
                color = textColor,
                fontSize = 34.sp,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "EDIT SPLIT",
                color = secondaryTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
        }

        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = nameDraft.uppercase(),
            color = textColor,
            fontSize = 38.sp,
            lineHeight = 38.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.8).sp
        )
        OutlinedTextField(
            value = nameDraft,
            onValueChange = {
                nameDraft = it
                onSplitChanged(split.copy(name = it))
            },
            label = { Text("SPLIT NAME") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp)
        )

        Spacer(modifier = Modifier.height(18.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SCHEDULE",
                color = if (selectedTab == "SCHEDULE") textColor else secondaryTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { selectedTab = "SCHEDULE" }
            )
            Spacer(modifier = Modifier.width(24.dp))
            Text(
                text = "EXERCISES",
                color = if (selectedTab == "EXERCISES") textColor else secondaryTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { selectedTab = "EXERCISES" }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Hairline(textColor.copy(alpha = 0.18f))

        if (selectedTab == "SCHEDULE") {
            Spacer(modifier = Modifier.height(10.dp))
            DayOfWeek.values().forEach { day ->
                val workout = split.days[day]!!
                ScheduleDayRow(
                    day = day,
                    workout = workout,
                    cardColor = cardColor,
                    textColor = textColor,
                    secondaryTextColor = secondaryTextColor,
                    onEdit = {
                        selectedDay = day
                        showDayEditor = true
                    }
                )
            }
        } else {
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DayOfWeek.values().forEach { day ->
                    val selected = day == selectedDay
                    Text(
                        text = day.name.take(3),
                        color = if (selected) textColor else secondaryTextColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { selectedDay = day }
                            .padding(end = 18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))
            if (selectedWorkout?.type == WorkoutType.TRAINING) {
                Text(
                    text = selectedWorkout.name.uppercase(),
                    color = textColor,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${selectedWorkout.exercises.size} EXERCISES",
                    color = secondaryTextColor,
                    fontSize = 10.sp,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                selectedWorkout.exercises.forEachIndexed { index, exercise ->
                    ExerciseRow(
                        exercise = exercise,
                        cardColor = cardColor,
                        textColor = textColor,
                        secondaryTextColor = secondaryTextColor,
                        onDelete = {
                            val updatedExercises = selectedWorkout.exercises.toMutableList()
                            updatedExercises.removeAt(index)
                            onSplitChanged(
                                split.copy(
                                    days = split.days + (selectedDay to selectedWorkout.copy(exercises = updatedExercises))
                                )
                            )
                        }
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, textColor.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                        .clickable { showAddExercise = true }
                        .padding(vertical = 15.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "+ ADD EXERCISE",
                        color = textColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }
            } else {
                Text(
                    text = "REST DAY",
                    color = textColor,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "EDIT THE DAY ABOVE TO MAKE IT A TRAINING DAY.",
                    color = secondaryTextColor,
                    fontSize = 10.sp,
                    letterSpacing = 0.6.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        if (!isActive) {
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "USE THIS SPLIT",
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
                modifier = Modifier.clickable { onUseSplit() }
            )
        }
        Spacer(modifier = Modifier.height(22.dp))
    }

    if (showDayEditor && selectedWorkout != null) {
        EditWorkoutDayDialog(
            workout = selectedWorkout,
            onDismiss = { showDayEditor = false },
            onSave = { updated ->
                onSplitChanged(split.copy(days = split.days + (selectedDay to updated)))
                showDayEditor = false
            }
        )
    }

    if (showAddExercise && selectedWorkout != null) {
        AddExerciseDialog(
            onDismiss = { showAddExercise = false },
            onAdd = { exercise ->
                onSplitChanged(
                    split.copy(
                        days = split.days + (
                                selectedDay to selectedWorkout.copy(
                                    exercises = selectedWorkout.exercises + exercise
                                )
                                )
                    )
                )
                showAddExercise = false
            }
        )
    }
}

@Composable
fun EditorTab(
    label: String,
    selected: Boolean,
    textColor: Color,
    secondaryTextColor: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clickable { onClick() }
            .background(
                color = if (selected) textColor.copy(alpha = 0.10f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .border(
                1.dp,
                if (selected) Color.White.copy(alpha = 0.10f) else Color.Transparent,
                RoundedCornerShape(12.dp)
            )
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) textColor else secondaryTextColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun ScheduleDayRow(
    day: DayOfWeek,
    workout: WorkoutDay,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onEdit: () -> Unit
) {
    Column {
        LiquidGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onEdit() },
            cardColor = cardColor,
            cornerRadius = 17.dp,
            glowColor = if (workout.type == WorkoutType.TRAINING) {
                workout.color.copy(alpha = 0.08f)
            } else {
                textColor.copy(alpha = 0.05f)
            }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 15.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .background(
                            if (workout.type == WorkoutType.TRAINING) workout.color else secondaryTextColor.copy(alpha = 0.22f),
                            CircleShape
                        )
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = day.name.uppercase(),
                        color = secondaryTextColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = workout.name,
                        color = textColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
                Text(
                    text = "EDIT",
                    color = secondaryTextColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
fun EditWorkoutDayDialog(
    workout: WorkoutDay,
    onDismiss: () -> Unit,
    onSave: (WorkoutDay) -> Unit
) {

    var name by remember {
        mutableStateOf(workout.name)
    }

    var minutes by remember {
        mutableStateOf(
            workout.estimatedMinutes.toString()
        )
    }

    var type by remember {
        mutableStateOf(workout.type)
    }

    var selectedColor by remember {
        mutableStateOf(workout.color)
    }

    val colors = listOf(
        Color(0xFF303030),
        Color(0xFF553355),
        Color(0xFF244C63),
        Color(0xFF4A5730),
        Color(0xFF624232),
        Color(0xFF4D3A5F),
        Color(0xFF663333),
        Color(0xFF365C52)
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {

        Column(
            modifier =
                Modifier
                    .fillMaxWidth(0.92f)
                    .background(
                        color = Color(0xFF202020).copy(alpha = 0.94f),
                        shape =
                            RoundedCornerShape(
                                26.dp
                            )
                    )
                    .padding(22.dp)
        ) {

            Text(
                text =
                    "EDIT ${workout.day.name}",

                color = Color.White,
                fontSize = 22.sp,
                fontWeight =
                    FontWeight.Bold
            )

            Spacer(
                modifier =
                    Modifier.height(18.dp)
            )

            OutlinedTextField(
                value = name,

                onValueChange = {
                    name = it
                },

                label = {
                    Text("WORKOUT NAME")
                },

                singleLine = true,

                modifier =
                    Modifier.fillMaxWidth()
            )

            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )

            Text(
                text = "TYPE",
                color = Color.LightGray,
                fontSize = 11.sp
            )

            Spacer(
                modifier =
                    Modifier.height(8.dp)
            )

            Row {

                TypeButton(
                    label = "TRAINING",
                    selected =
                        type ==
                                WorkoutType.TRAINING,
                    onClick = {
                        type =
                            WorkoutType.TRAINING
                    }
                )

                Spacer(
                    modifier =
                        Modifier.width(8.dp)
                )

                TypeButton(
                    label = "REST",
                    selected =
                        type ==
                                WorkoutType.REST,
                    onClick = {
                        type =
                            WorkoutType.REST
                    }
                )
            }

            if (
                type ==
                WorkoutType.TRAINING
            ) {

                Spacer(
                    modifier =
                        Modifier.height(14.dp)
                )

                OutlinedTextField(
                    value = minutes,

                    onValueChange = {
                        minutes =
                            it.filter {
                                    char ->
                                char.isDigit()
                            }
                    },

                    label = {
                        Text("ESTIMATED MINUTES")
                    },

                    singleLine = true,

                    modifier =
                        Modifier.fillMaxWidth()
                )
            }

            Spacer(
                modifier =
                    Modifier.height(16.dp)
            )

            Text(
                text = "COLOR",
                color = Color.LightGray,
                fontSize = 11.sp
            )

            Spacer(
                modifier =
                    Modifier.height(10.dp)
            )

            Row(
                modifier =
                    Modifier.fillMaxWidth(),
                horizontalArrangement =
                    Arrangement.spacedBy(9.dp)
            ) {

                colors.forEach { color ->

                    ColorChoice(
                        color = color,
                        selected =
                            color ==
                                    selectedColor,
                        onClick = {
                            selectedColor =
                                color
                        }
                    )
                }
            }

            Spacer(
                modifier =
                    Modifier.height(22.dp)
            )

            Row(
                modifier =
                    Modifier.fillMaxWidth()
            ) {

                Box(
                    modifier =
                        Modifier
                            .weight(1f)
                            .height(46.dp)
                            .background(
                                color =
                                    Color.DarkGray,
                                shape =
                                    RoundedCornerShape(
                                        13.dp
                                    )
                            )
                            .clickable {
                                onDismiss()
                            },

                    contentAlignment =
                        Alignment.Center
                ) {

                    Text(
                        text = "CANCEL",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight =
                            FontWeight.Bold
                    )
                }

                Spacer(
                    modifier =
                        Modifier.width(10.dp)
                )

                Box(
                    modifier =
                        Modifier
                            .weight(1f)
                            .height(46.dp)
                            .background(
                                color = Color.White,
                                shape =
                                    RoundedCornerShape(
                                        13.dp
                                    )
                            )
                            .clickable {

                                val finalMinutes =
                                    if (
                                        type ==
                                        WorkoutType.REST
                                    ) {
                                        0
                                    } else {
                                        minutes
                                            .toIntOrNull()
                                            ?: workout
                                                .estimatedMinutes
                                    }

                                val updated =
                                    workout.copy(
                                        name =
                                            name.ifBlank {
                                                workout.name
                                            },

                                        estimatedMinutes =
                                            finalMinutes,

                                        type = type,

                                        color =
                                            selectedColor,

                                        exercises =
                                            if (
                                                type ==
                                                WorkoutType.REST
                                            ) {
                                                emptyList()
                                            } else {
                                                workout.exercises
                                            }
                                    )

                                onSave(updated)
                            },

                    contentAlignment =
                        Alignment.Center
                ) {

                    Text(
                        text = "SAVE",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontWeight =
                            FontWeight.Bold
                    )
                }
            }
        }
    }
}


/* ============================================================
   COLOR CHOICE
   ============================================================ */

@Composable
fun ColorChoice(
    color: Color,
    selected: Boolean,
    onClick: () -> Unit
) {

    Box(
        modifier =
            Modifier
                .size(30.dp)
                .background(
                    color = color,
                    shape = CircleShape
                )
                .border(
                    width =
                        if (selected) {
                            2.dp
                        } else {
                            0.dp
                        },

                    color = Color.White,
                    shape = CircleShape
                )
                .clickable {
                    onClick()
                }
    )
}


/* ============================================================
   TYPE BUTTON
   ============================================================ */

@Composable
fun TypeButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {

    Box(
        modifier =
            Modifier
                .background(
                    color =
                        if (selected) {
                            Color.White
                        } else {
                            Color(0xFF303030)
                        },

                    shape =
                        RoundedCornerShape(12.dp)
                )
                .clickable {
                    onClick()
                }
                .padding(
                    horizontal = 14.dp,
                    vertical = 10.dp
                )
    ) {

        Text(
            text = label,

            color =
                if (selected) {
                    Color.Black
                } else {
                    Color.White
                },

            fontSize = 10.sp,
            fontWeight =
                FontWeight.Bold
        )
    }
}


/* ============================================================
   EXERCISE ROW
   ============================================================ */

@Composable
fun ExerciseRow(
    exercise: Exercise,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onDelete: () -> Unit
) {
    Column {
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cardColor = cardColor,
            cornerRadius = 17.dp,
            glowColor = textColor.copy(alpha = 0.05f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 15.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = exercise.name,
                        color = textColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "${exercise.sets} SETS · ${exercise.reps}",
                        color = secondaryTextColor,
                        fontSize = 9.sp,
                        letterSpacing = 0.7.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
                Text(
                    text = "×",
                    color = secondaryTextColor,
                    fontSize = 18.sp,
                    modifier = Modifier.clickable { onDelete() }
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
fun AddExerciseDialog(
    onDismiss: () -> Unit,
    onAdd: (Exercise) -> Unit
) {

    var name by remember {
        mutableStateOf("")
    }

    var sets by remember {
        mutableStateOf("3")
    }

    var reps by remember {
        mutableStateOf("8-12")
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {

        Column(
            modifier =
                Modifier
                    .fillMaxWidth(0.92f)
                    .background(
                        color = Color(0xFF202020).copy(alpha = 0.94f),
                        shape =
                            RoundedCornerShape(
                                26.dp
                            )
                    )
                    .padding(22.dp)
        ) {

            Text(
                text = "ADD EXERCISE",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight =
                    FontWeight.Bold
            )

            Spacer(
                modifier =
                    Modifier.height(18.dp)
            )

            OutlinedTextField(
                value = name,

                onValueChange = {
                    name = it
                },

                label = {
                    Text("EXERCISE NAME")
                },

                singleLine = true,

                modifier =
                    Modifier.fillMaxWidth()
            )

            Spacer(
                modifier =
                    Modifier.height(12.dp)
            )

            Row(
                modifier =
                    Modifier.fillMaxWidth()
            ) {

                OutlinedTextField(
                    value = sets,

                    onValueChange = {
                        sets =
                            it.filter {
                                    char ->
                                char.isDigit()
                            }
                    },

                    label = {
                        Text("SETS")
                    },

                    singleLine = true,

                    modifier =
                        Modifier.weight(1f)
                )

                Spacer(
                    modifier =
                        Modifier.width(10.dp)
                )

                OutlinedTextField(
                    value = reps,

                    onValueChange = {
                        reps = it
                    },

                    label = {
                        Text("REPS")
                    },

                    singleLine = true,

                    modifier =
                        Modifier.weight(1f)
                )
            }

            Spacer(
                modifier =
                    Modifier.height(22.dp)
            )

            Row(
                modifier =
                    Modifier.fillMaxWidth()
            ) {

                Box(
                    modifier =
                        Modifier
                            .weight(1f)
                            .height(46.dp)
                            .background(
                                color =
                                    Color.DarkGray,
                                shape =
                                    RoundedCornerShape(
                                        13.dp
                                    )
                            )
                            .clickable {
                                onDismiss()
                            },

                    contentAlignment =
                        Alignment.Center
                ) {

                    Text(
                        text = "CANCEL",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight =
                            FontWeight.Bold
                    )
                }

                Spacer(
                    modifier =
                        Modifier.width(10.dp)
                )

                Box(
                    modifier =
                        Modifier
                            .weight(1f)
                            .height(46.dp)
                            .background(
                                color = Color.White,
                                shape =
                                    RoundedCornerShape(
                                        13.dp
                                    )
                            )
                            .clickable {

                                if (
                                    name.isNotBlank()
                                ) {

                                    onAdd(
                                        Exercise(
                                            name = name,
                                            sets =
                                                sets
                                                    .toIntOrNull()
                                                    ?: 3,
                                            reps = reps
                                        )
                                    )
                                }
                            },

                    contentAlignment =
                        Alignment.Center
                ) {

                    Text(
                        text = "ADD",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontWeight =
                            FontWeight.Bold
                    )
                }
            }
        }
    }
}


/* ============================================================
   PROGRESS
   ============================================================ */

@Composable
fun ProgressScreen(
    split: WorkoutSplit
) {
    val context = LocalContext.current
    val database = remember { GymFlowDatabase.getInstance(context) }
    var sessions by remember { mutableStateOf<List<WorkoutSessionEntity>>(emptyList()) }
    var exerciseSets by remember { mutableStateOf<List<ExerciseSetEntity>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedExercise by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        sessions = database.workoutSessionDao().getAllSessions()
        exerciseSets = database.exerciseSetDao().getAllSets()
        isLoading = false
    }

    val backgroundColor = getWorkoutThemeColor(getWorkoutForToday(split))
    val cardColor = getCardColor(backgroundColor)
    val textColor = getTextColor(backgroundColor)
    val secondaryTextColor = getSecondaryTextColor(backgroundColor)

    if (selectedExercise != null) {
        ExerciseProgressDetailScreen(
            exerciseName = selectedExercise!!,
            sessions = sessions,
            exerciseSets = exerciseSets,
            backgroundColor = backgroundColor,
            cardColor = cardColor,
            textColor = textColor,
            secondaryTextColor = secondaryTextColor,
            onBack = { selectedExercise = null }
        )
        return
    }

    val currentMonth = YearMonth.from(LocalDate.now())
    val thisMonthSessions = sessions.filter {
        runCatching { YearMonth.from(LocalDate.parse(it.workoutDate)) }.getOrNull() == currentMonth
    }
    val gymMinutes = thisMonthSessions.sumOf {
        ((it.finishedAt - it.startedAt) / 60_000L).toInt().coerceAtLeast(0)
    }
    val thisMonthIds = thisMonthSessions.map { it.id }.toSet()
    val thisMonthSets = exerciseSets.filter { it.sessionId in thisMonthIds && it.completed }
    val allTimeMax = exerciseSets.filter { it.completed && it.weight > 0f }
        .groupBy { it.exerciseName }
        .mapValues { (_, sets) -> sets.maxOf { it.weight } }
    val monthlyMax = thisMonthSets.filter { it.weight > 0f }
        .groupBy { it.exerciseName }
        .mapValues { (_, sets) -> sets.maxOf { it.weight } }
    val personalRecords = monthlyMax.count { (exercise, monthMax) -> monthMax >= (allTimeMax[exercise] ?: -1f) }
    val exerciseNames = (split.days.values.flatMap { it.exercises }.map { it.name } + exerciseSets.map { it.exerciseName }).distinct()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 28.dp)
    ) {
        Text(
            text = "PROGRESS",
            color = textColor,
            fontSize = 40.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-1).sp
        )
        Text(
            text = "TRAINING RECORD",
            color = secondaryTextColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(26.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            ProgressStatCard(
                title = "WORKOUTS",
                value = if (isLoading) "—" else thisMonthSessions.size.toString(),
                subtitle = "THIS MONTH",
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(1.dp))
            ProgressStatCard(
                title = "GYM TIME",
                value = if (isLoading) "—" else "${gymMinutes / 60}H ${gymMinutes % 60}M",
                subtitle = "THIS MONTH",
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(1.dp))
            ProgressStatCard(
                title = "PRS",
                value = if (isLoading) "—" else personalRecords.toString(),
                subtitle = "THIS MONTH",
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))
        Hairline(textColor.copy(alpha = 0.18f))
        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = "EXERCISES",
            color = secondaryTextColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (exerciseNames.isEmpty()) {
            ScheduleEmptyCard(
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                onAdd = { }
            )
        } else {
            exerciseNames.forEach { exercise ->
                val history = exerciseSets.filter { it.exerciseName == exercise && it.completed }
                val bestWeight = history.filter { it.weight > 0f }.maxOfOrNull { it.weight }
                val bestReps = history.filter { it.reps > 0 }.maxOfOrNull { it.reps }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedExercise = exercise }
                        .padding(vertical = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = exercise,
                            color = textColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = when {
                                bestWeight != null -> "BEST ${bestWeight} KG"
                                bestReps != null -> "BEST ${bestReps} REPS"
                                else -> "NO LOGGED SETS"
                            },
                            color = secondaryTextColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.7.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    Text(text = "›", color = secondaryTextColor, fontSize = 22.sp)
                }
                Hairline(secondaryTextColor.copy(alpha = 0.14f))
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun ExerciseProgressDetailScreen(
    exerciseName: String,
    sessions: List<WorkoutSessionEntity>,
    exerciseSets: List<ExerciseSetEntity>,
    backgroundColor: Color,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onBack: () -> Unit
) {
    val sessionMap = sessions.associateBy { it.id }
    val historyBySession = exerciseSets
        .filter { it.exerciseName == exerciseName && it.completed && sessionMap.containsKey(it.sessionId) }
        .groupBy { it.sessionId }

    val history = historyBySession.mapNotNull { (sessionId, sets) ->
        val session = sessionMap[sessionId] ?: return@mapNotNull null
        val bestWeight = sets.filter { it.weight > 0f }.maxOfOrNull { it.weight }
        val bestReps = sets.filter { it.reps > 0 }.maxOfOrNull { it.reps }
        Triple(session.finishedAt, bestWeight, bestReps)
    }.sortedBy { it.first }

    val usesWeight = history.any { it.second != null }
    val points: List<ExerciseProgressPoint> = history.mapNotNull { item ->
        val value: Float? = if (usesWeight) item.second else item.third?.toFloat()
        value?.let { pointValue ->
            ExerciseProgressPoint(
                dateLabel = runCatching {
                    val session = sessionMap.values.firstOrNull { it.finishedAt == item.first }
                    val date = LocalDate.parse(session?.workoutDate ?: "")
                    "${date.dayOfMonth}/${date.monthValue}"
                }.getOrNull() ?: "—",
                value = pointValue
            )
        }
    }

    val bestValue = points.maxOfOrNull { it.value } ?: 0f
    val lastValue = points.lastOrNull()?.value ?: 0f
    val sessionCount = history.size
    val totalSets = historyBySession.values.sumOf { it.size }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 26.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "‹",
                color = textColor,
                fontSize = 34.sp,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "EXERCISE",
                color = secondaryTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = exerciseName.uppercase(),
            color = textColor,
            fontSize = 38.sp,
            lineHeight = 38.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.8).sp
        )
        Text(
            text = if (usesWeight) "WEIGHT · KG" else "REPS",
            color = secondaryTextColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(22.dp))
        if (points.isEmpty()) {
            ScheduleEmptyCard(
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                onAdd = { }
            )
        } else {
            ProgressLineChart(
                points = points,
                lineColor = textColor,
                gridColor = secondaryTextColor.copy(alpha = 0.16f)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = points.first().dateLabel, color = secondaryTextColor, fontSize = 9.sp)
                Text(text = points.last().dateLabel, color = secondaryTextColor, fontSize = 9.sp)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            ExerciseDetailStat(
                title = "BEST",
                value = if (points.isEmpty()) "—" else formatProgressValue(bestValue, usesWeight),
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.weight(1f)
            )
            ExerciseDetailStat(
                title = "LAST",
                value = if (points.isEmpty()) "—" else formatProgressValue(lastValue, usesWeight),
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.weight(1f)
            )
            ExerciseDetailStat(
                title = "SESSIONS",
                value = sessionCount.toString(),
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.weight(1f)
            )
            ExerciseDetailStat(
                title = "SETS",
                value = totalSets.toString(),
                cardColor = cardColor,
                textColor = textColor,
                secondaryTextColor = secondaryTextColor,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(22.dp))
        Text(
            text = "RECENT HISTORY",
            color = secondaryTextColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        history.asReversed().take(8).forEach { item ->
            val date = sessionMap.values.firstOrNull { it.finishedAt == item.first }?.workoutDate ?: "—"
            val weight = item.second
            val reps = item.third
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = date,
                    color = secondaryTextColor,
                    fontSize = 11.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = when {
                        weight != null && reps != null -> "${weight} KG · $reps REPS"
                        weight != null -> "${weight} KG"
                        reps != null -> "$reps REPS"
                        else -> "—"
                    },
                    color = textColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Hairline(secondaryTextColor.copy(alpha = 0.14f))
        }
        Spacer(modifier = Modifier.height(22.dp))
    }
}

fun formatProgressValue(value: Float, usesWeight: Boolean): String {
    val formatted = if (value % 1f == 0f) {
        value.toInt().toString()
    } else {
        "%.1f".format(value)
    }
    return if (usesWeight) "$formatted kg" else "$formatted reps"
}

@Composable
fun ProgressLineChart(
    points: List<ExerciseProgressPoint>,
    lineColor: Color,
    gridColor: Color
) {
    val values = points.map { it.value }
    val minValueRaw = values.minOrNull() ?: 0f
    val maxValueRaw = values.maxOrNull() ?: 1f
    val range = (maxValueRaw - minValueRaw).coerceAtLeast(1f)
    val minValue = minValueRaw - range * 0.10f
    val maxValue = maxValueRaw + range * 0.10f

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
    ) {
        val horizontalPadding = 8f
        val verticalPadding = 12f
        val graphWidth = size.width - horizontalPadding * 2f
        val graphHeight = size.height - verticalPadding * 2f

        repeat(4) { index ->
            val y = verticalPadding +
                    (graphHeight * index / 3f)

            drawLine(
                color = gridColor,
                start = Offset(horizontalPadding, y),
                end = Offset(size.width - horizontalPadding, y),
                strokeWidth = 1f
            )
        }

        val path = Path()

        points.forEachIndexed { index, point ->
            val x = if (points.size == 1) {
                size.width / 2f
            } else {
                horizontalPadding +
                        graphWidth * index / (points.size - 1).toFloat()
            }

            val normalized =
                ((point.value - minValue) / (maxValue - minValue))
                    .coerceIn(0f, 1f)

            val y =
                verticalPadding +
                        graphHeight * (1f - normalized)

            if (index == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        if (points.size > 1) {
            drawPath(
                path = path,
                color = lineColor,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 5f
                )
            )
        }

        points.forEachIndexed { index, point ->
            val x = if (points.size == 1) {
                size.width / 2f
            } else {
                horizontalPadding +
                        graphWidth * index / (points.size - 1).toFloat()
            }

            val normalized =
                ((point.value - minValue) / (maxValue - minValue))
                    .coerceIn(0f, 1f)

            val y =
                verticalPadding +
                        graphHeight * (1f - normalized)

            drawCircle(
                color = lineColor,
                radius = 6f,
                center = Offset(x, y)
            )
        }
    }
}

@Composable
fun ExerciseDetailStat(
    title: String,
    value: String,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    modifier: Modifier = Modifier
) {
    LiquidGlassCard(
        modifier = modifier.padding(end = 7.dp),
        cardColor = cardColor,
        cornerRadius = 15.dp,
        glowColor = textColor.copy(alpha = 0.05f)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                color = secondaryTextColor,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.7.sp
            )
            Text(
                text = value,
                color = textColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun ProgressStatCard(
    title: String,
    value: String,
    subtitle: String,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    modifier: Modifier = Modifier
) {
    LiquidGlassCard(
        modifier = modifier.padding(end = 8.dp),
        cardColor = cardColor,
        cornerRadius = 18.dp,
        glowColor = textColor.copy(alpha = 0.06f)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Text(
                text = title,
                color = secondaryTextColor,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.6.sp
            )
            Text(
                text = value,
                color = textColor,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text(
                text = subtitle,
                color = secondaryTextColor,
                fontSize = 8.sp,
                letterSpacing = 0.4.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun ProfileScreen(
    splitCount: Int,
    backgroundColor: Color,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val user = FirebaseAuth.getInstance().currentUser

    var notificationsEnabled by remember {
        mutableStateOf(
            GymFlowNotifications.areScheduled(context)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 36.dp)
    ) {
        Text(
            text = "PROFILE",
            color = textColor,
            fontSize = 36.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Text(
            text = "YOUR GYM FLOW",
            color = secondaryTextColor,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(26.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = cardColor,
                    shape = RoundedCornerShape(22.dp)
                )
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "GOOGLE ACCOUNT",
                    color = secondaryTextColor,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(7.dp))

                Text(
                    text = user?.displayName?.takeIf { it.isNotBlank() }
                        ?: "GymFlow user",
                    color = textColor,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = user?.email ?: "",
                    color = secondaryTextColor,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "$splitCount saved splits",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = cardColor,
                    shape = RoundedCornerShape(18.dp)
                )
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "NOTIFICATIONS",
                        color = secondaryTextColor,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (notificationsEnabled) {
                            "Daily workout reminder · 18:00"
                        } else {
                            "Workout reminders are off"
                        },
                        color = textColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = if (notificationsEnabled) "ON" else "OFF",
                    color = textColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            if (notificationsEnabled) {
                                GymFlowNotifications.cancelDailyReminder(context)
                                notificationsEnabled = false
                            } else {
                                GymFlowNotifications.scheduleDailyReminder(
                                    context = context,
                                    workoutName = "today's workout"
                                )
                                notificationsEnabled =
                                    GymFlowNotifications.areScheduled(context)
                            }
                        }
                        .background(
                            color = textColor.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(
                            horizontal = 14.dp,
                            vertical = 9.dp
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        ProfileRow(
            title = "CALENDAR CONNECTION",
            value = "Local GymFlow calendar",
            cardColor = cardColor,
            textColor = textColor,
            secondaryTextColor = secondaryTextColor
        )

        Spacer(modifier = Modifier.height(10.dp))

        ProfileRow(
            title = "APP SETTINGS",
            value = "GymFlow preferences",
            cardColor = cardColor,
            textColor = textColor,
            secondaryTextColor = secondaryTextColor
        )

        Spacer(modifier = Modifier.height(18.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .clip(RoundedCornerShape(16.dp))
                .clickable { onLogout() }
                .background(
                    color = cardColor,
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "LOG OUT",
                color = textColor,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun ProfileRow(
    title: String,
    value: String,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color
) {
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        cardColor = cardColor,
        cornerRadius = 18.dp,
        glowColor = textColor.copy(alpha = 0.06f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = secondaryTextColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = value,
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Text(text = "›", color = secondaryTextColor, fontSize = 22.sp)
        }
    }
}

@Composable
fun GymFlowBottomBar(
    selectedScreen: String,
    onScreenSelected: (String) -> Unit,
    cardColor: Color,
    textColor: Color,
    secondaryTextColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .blur(30.dp)
                .background(
                    color = textColor.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(32.dp)
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .background(
                    color = cardColor.copy(alpha = 0.40f),
                    shape = RoundedCornerShape(32.dp)
                )
                .border(
                    1.dp,
                    Color.White.copy(alpha = 0.16f),
                    RoundedCornerShape(32.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .padding(horizontal = 26.dp)
                    .align(Alignment.TopCenter)
                    .background(
                        Color.White.copy(alpha = 0.15f),
                        RoundedCornerShape(1.dp)
                    )
            )
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 7.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("HOME", "CALENDAR", "SPLIT", "PROGRESS", "PROFILE").forEach { screen ->
                    BottomBarItem(
                        modifier = Modifier.weight(1f),
                        label = screen,
                        selected = selectedScreen == screen,
                        onClick = { onScreenSelected(screen) },
                        textColor = textColor,
                        secondaryTextColor = secondaryTextColor
                    )
                }
            }
        }
    }
}

@Composable
fun BottomBarItem(
    modifier: Modifier,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    textColor: Color,
    secondaryTextColor: Color
) {
    Box(
        modifier = modifier
            .fillMaxHeight()
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        NavIcon(
            name = label,
            color = if (selected) textColor else secondaryTextColor.copy(alpha = 0.62f),
            selected = selected
        )
    }
}


@Composable
fun Hairline(color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(color)
    )
}


/* ============================================================
   PREVIEW
   ============================================================ */


/* ============================================================
   NOTIFICATIONS
   ============================================================ */

object GymFlowNotifications {

    private const val CHANNEL_ID = "gymflow_workout_reminders"
    private const val CHANNEL_NAME = "Workout reminders"
    private const val REQUEST_CODE = 7319
    private const val PREFS = "gymflow_notification_prefs"
    private const val KEY_ENABLED = "daily_reminder_enabled"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Reminders for your GymFlow workout"
            }

            context.getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
    }

    fun scheduleDailyReminder(
        context: Context,
        workoutName: String,
        hour: Int = 18,
        minute: Int = 0
    ) {
        createChannel(context)

        val alarmManager = context.getSystemService(AlarmManager::class.java)
            ?: return

        val intent = Intent(context, GymFlowReminderReceiver::class.java).apply {
            putExtra("workout_name", workoutName)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)

            if (timeInMillis <= System.currentTimeMillis()) {
                add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
        }

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, true)
            .apply()
    }

    fun cancelDailyReminder(context: Context) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
            ?: return

        val intent = Intent(context, GymFlowReminderReceiver::class.java)

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )

        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, false)
            .apply()
    }

    fun areScheduled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)
}

class GymFlowReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        GymFlowNotifications.createChannel(context)

        val workoutName = intent.getStringExtra("workout_name")
            ?: "Today's workout"

        val notification = androidx.core.app.NotificationCompat.Builder(
            context,
            "gymflow_workout_reminders"
        )
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("GymFlow")
            .setContentText("It's time to check your $workoutName plan.")
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        val manager = androidx.core.app.NotificationManagerCompat.from(context)

        if (
            Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            manager.notify(1001, notification)
        }
    }
}


/* ============================================================
   GMAIL
   ============================================================ */



@Preview(
    showBackground = true,
    showSystemUi = true
)
@Composable
fun GymFlowPreview() {
    GymFlowApp()
}
