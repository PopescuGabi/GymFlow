package com.example.gymflow

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ScheduleEventDao {

    @Insert
    suspend fun insertEvent(
        event: ScheduleEventEntity
    ): Long

    @Query(
        """
        SELECT *
        FROM schedule_events
        WHERE eventDate = :date
        ORDER BY startMinutes ASC
        """
    )
    suspend fun getEventsForDate(
        date: String
    ): List<ScheduleEventEntity>

    @Query(
        """
        SELECT *
        FROM schedule_events
        WHERE eventDate BETWEEN :startDate AND :endDate
        ORDER BY eventDate ASC, startMinutes ASC
        """
    )
    suspend fun getEventsForDateRange(
        startDate: String,
        endDate: String
    ): List<ScheduleEventEntity>

    @Query(
        """
        DELETE FROM schedule_events
        WHERE id = :eventId
        """
    )
    suspend fun deleteEvent(
        eventId: Long
    )
}