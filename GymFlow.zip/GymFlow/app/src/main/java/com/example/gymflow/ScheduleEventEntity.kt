package com.example.gymflow

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "schedule_events")
data class ScheduleEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val eventDate: String,
    val title: String,
    val startMinutes: Int,
    val endMinutes: Int,
    val category: String,
    val notes: String = ""
)


