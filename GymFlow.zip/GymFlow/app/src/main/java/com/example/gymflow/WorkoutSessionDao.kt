package com.example.gymflow


import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface WorkoutSessionDao {

    @Insert
    suspend fun insertSession(session: WorkoutSessionEntity): Long

    @Delete
    suspend fun deleteSession(session: WorkoutSessionEntity)

    @Query(
        """
        SELECT * 
        FROM workout_sessions
        ORDER BY workoutDate DESC, finishedAt DESC
        """
    )
    suspend fun getAllSessions(): List<WorkoutSessionEntity>

    @Query(
        """
        SELECT *
        FROM workout_sessions
        ORDER BY workoutDate DESC, finishedAt DESC
        LIMIT 10
        """
    )
    suspend fun getRecentSessions(): List<WorkoutSessionEntity>
}