package com.example.gymflow


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workout_sessions")
data class WorkoutSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val splitId: Int,
    val workoutName: String,
    val workoutDate: String,

    val startedAt: Long,
    val finishedAt: Long,

    val estimatedMinutes: Int
)